# Classic Program Include Layout

Read this reference when creating a new custom classic executable program or module pool. It defines the default source layout. A closer user/project convention or a verified target-system restriction takes precedence.

## Object Set

For program `<PROGRAM>`, derive these seven include names:

| Order | Include | Owns |
| --- | --- | --- |
| 1 | `<PROGRAM>_TOP` | Global types, constants, tables, data, field symbols and other shared declarations |
| 2 | `<PROGRAM>_CLS` | Local class definitions and implementations |
| 3 | `<PROGRAM>_SCR` | `PARAMETERS`, `SELECT-OPTIONS`, `SELECTION-SCREEN` layout and other selection-screen declarations |
| 4 | `<PROGRAM>_FRM` | `FORM ... ENDFORM` routines only |
| 5 | `<PROGRAM>_EVT` | Executable-report event blocks such as `INITIALIZATION`, `AT SELECTION-SCREEN`, `START-OF-SELECTION`, `END-OF-SELECTION`, list events and their orchestration |
| 6 | `<PROGRAM>_PBO` | Dynpro `MODULE ... OUTPUT` implementations only |
| 7 | `<PROGRAM>_PAI` | Dynpro `MODULE ... INPUT` implementations only |

Use the exact project-approved names in SAP. Before creation, verify every derived name against the target system's repository naming rules. If any name is invalid or too long, present an explicit seven-name mapping for approval; do not silently truncate or invent abbreviations.

The main executable program contains its `REPORT` declaration, required report attributes/directives and the includes in this exact order:

```abap
INCLUDE <PROGRAM>_TOP.
INCLUDE <PROGRAM>_CLS.
INCLUDE <PROGRAM>_SCR.
INCLUDE <PROGRAM>_FRM.
INCLUDE <PROGRAM>_EVT.
INCLUDE <PROGRAM>_PBO.
INCLUDE <PROGRAM>_PAI.
```

For a module pool, retain the valid `PROGRAM` declaration instead of converting it to `REPORT`; keep the same include order. Create all seven includes even when a particular program initially has no selection screen or Dynpro logic. An unused include stays empty except for an optional concise ownership header permitted by the project style.

## Placement Rules

- Keep business declarations out of the main program. The main source is an assembly point, not an eighth implementation unit.
- Put a construct in one owning include. Do not duplicate shared declarations across includes to avoid dependency issues.
- Put selection-screen declarations in `SCR`, but put selection-screen processing events in `EVT`.
- Put report events in `EVT` as thin orchestration. Move reusable calculations, validation and data access into coherent local-class methods in `CLS`, or into `FRM` when the existing design intentionally uses forms.
- Put only PBO modules in `PBO` and only PAI modules in `PAI`. Flow logic remains part of the Dynpro definition, not ABAP include source.
- Prefer dependency flow from `EVT`, `PBO` and `PAI` into `CLS` or `FRM`. Avoid new circular dependencies between local classes and forms.
- A FORM belongs wholly in `FRM`; a local class definition and its implementation both belong in `CLS`. Do not split one construct across arbitrary includes.
- Follow the target release's syntax. This layout does not authorize modernization or use of unsupported statements.

## Creation and Change Safety

Treat the main program plus seven includes as eight separate repository objects for discovery, collision checks, authorization, package/transport handling and evidence. A user request for “a program” may express the desired deliverable, but before mutation list the exact eight object names and confirm that they are within the approved scope.

1. Search the exact main program and all seven include names. Do not overwrite any existing object or inactive draft.
2. Verify object types, package, target release and existing transport requirements. Do not assume all creation tools support every program kind.
3. Choose a creation order compatible with the installed tool's save/activation behavior. Ensure referenced includes exist before activating the assembled main program.
4. Populate implementation in dependency order so temporary activation does not reference missing declarations or routines. Keep event and screen modules as callers of already-defined reusable logic where practical.
5. After each mutation, preserve the receipt and read back the exact object. On a partial failure, report which of the eight objects exist and their active/inactive states; do not automatically delete or retry them.
6. Verify the main source has the exact ordered include list, each include contains only its assigned responsibility, and all eight objects use the approved package/transport state.

Activation and syntax checks prove repository consistency, not screen flow, report output or business behavior. Apply the task's separate testing authorization and evidence requirements.

## Existing Programs

For an existing program, preserve its established include architecture unless the user explicitly requests and authorizes a structural migration. A migration must inventory current includes, cross-include globals, dynamic PERFORMs, screen modules, variants, transactions and callers before moving code. Treat it as a compatibility-sensitive refactor, not routine formatting.
