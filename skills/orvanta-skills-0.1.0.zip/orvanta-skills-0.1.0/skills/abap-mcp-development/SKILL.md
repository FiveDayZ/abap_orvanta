---
name: abap-mcp-development
description: Implement explicitly requested SAP ABAP customer-object changes through ORVANTA or a compatible ABAP MCP service, using live source, dependency analysis, guarded writes and evidence-based verification. Use for ABAP development and fixes, not review-only requests, RFC documentation alone, or development of the MCP server itself.
---

# ABAP MCP Development

Support the user's requested behavior without assuming their SAP environment or granting permissions. Follow the host agent's instructions and the user's project rules. Respond in the user's language.

## Establish Context

1. Inspect the tools actually exposed by the connected MCP service and their current input schemas. The aliases in [references/tool-routing.md](references/tool-routing.md) are a source-based routing aid, not a promise of availability.
2. Discover connections. Resolve the intended system and client from explicit task context or current verified connection information. If ambiguous, ask before accessing a target. Never assume a connection ID, host, port, client, package, transport or production classification.
3. Establish the target ABAP release from available system information or user evidence. Use syntax and APIs supported by that target; if the release cannot be established, preserve existing syntax and disclose the uncertainty. Do not treat ECC and ABAP Cloud as interchangeable.
4. Read applicable project instructions. Determine the permitted customer objects, requested behavior, document destination and testing policy. Existing explicit authorization remains valid within its scope. Only ask for information that blocks a safe decision.

Connection failures, authorization failures and unsupported endpoints are not evidence that an object is absent. Continue independent read-only preparation where possible, but stop the blocked operation.

## Read Before Changing

- Resolve exact object types and server-provided URIs; do not construct SAP URIs or edit virtual SAP source through local filesystem tools.
- Read current source, interface and relevant DDIC definitions. Separate active, inactive and historical versions; use a current active baseline for comparison and preserve any existing draft.
- Trace the affected input, validation, authorization, locks, persistence, state transitions, transaction boundaries and outputs. Inspect callers and shared routines that can change the interpretation of the edited block.
- For function modules, include the function-group TOP/global declarations, relevant includes and called operations. For screen programs, include affected PBO/PAI and persistence paths.
- Verify referenced APIs, conversion exits, domains, locks and number ranges in the target system. Training knowledge is not proof of their existence.
- State the behavior to preserve and the failure cases to check. Keep code changes at the smallest complete ownership point.

## Make a Guarded Change

Before each mutation, confirm that the exact object, action and affected scope are authorized. Resolve and verify the package and existing transport where required; do not silently choose a local package or another request.

- Review requests, capability inspection and documentation requests do not authorize writes. Test permission does not authorize business-data changes, cleanup or transport release.
- Do not modify SAP standard objects. Do not treat a customer name alone as sufficient authorization.
- Re-read the exact target immediately before editing. Preserve a pre-change baseline and non-secret operation receipts in the project-approved location.
- Prefer the service's narrow source-replacement operation. Match `oldString` exactly once with stable surrounding context; do not enlarge the replacement to bypass an ambiguous match. Use an empty match only if the live source is truly blank and the current contract permits it.
- Supply a fresh full-source fingerprint when the tool supports one. Never derive a full-source fingerprint from a truncated or partial response.
- Use dedicated object-type operations for DDIC or interface changes after reading their live schema and impact requirements. Do not edit generated source to bypass those operations.
- Let the MCP service manage SAP locks, save, activation and cleanup. Do not manufacture session tokens, unlock another user's work, deploy helpers, change security configuration or weaken a guard to proceed.
- Object deletion, destructive schema changes, business execution and transport operations require their own explicit scope. The ordinary development request is not blanket approval.

If a write times out, loses its response or reports an unknown outcome, do not repeat it automatically. Retain the error and receipt identifier, inspect the supported operation-status mechanism and read back the target. Resume mutation only after the outcome and safe next action are established. Do not retry under a new operation identifier to bypass deduplication.

## Preserve ABAP Contracts

- Keep RFC inputs and outputs compatible unless a contract change was approved. Initialize request/output state so reused function-group sessions do not leak previous values.
- Validate before persistence; use authoritative DDIC types and established normalization. Preserve quantity/unit and amount/currency relationships.
- Guard empty `FOR ALL ENTRIES` drivers; check read/write results; make non-unique selections deterministic.
- Acquire the established business lock before reading mutable state, protect transitions from stale writes and preserve commit ownership. A source-edit lock is not a business lock.
- Do not introduce hidden commits, partial success, UI interaction in an RFC, unhandled messages or swallowed API errors.
- Keep retries, idempotency and partial-update versus replacement semantics explicit. Do not invent business rules where evidence is missing.

## Verify and Report

1. Inspect the write receipt and re-read the changed source through the exact target URI. Compare with the intended change and inspect active/inactive state.
2. Run permitted non-mutating syntax diagnostics for affected objects. Confirm activation from actual results; do not activate again when already confirmed. Any separate activation still requires applicable authorization.
3. Follow the user's testing policy. Where human-first applies, provide steps, expected results and required evidence without starting tests. Otherwise run only tests authorized by the task and environment. Never call a mutating RFC merely to check connectivity.
4. Distinguish syntax, activation, ATC/SCI, unit tests, runtime behavior and persisted business effects. Unsupported checks, missing tests and unavailable runtime evidence are gaps, not passes.
5. Record changed objects, source baseline, time with timezone, transport state, operation results and unverified risks in the user-approved project location. Do not impose a machine-specific path or overwrite historical records.

Use one status: `Passed` only when applicable required checks and runtime behavior have evidence; `Partially Verified` when implementation is complete but verification is incomplete; `Failed` when implementation is incomplete or a required check fails; `Review Only` when the work stayed read-only.

Conclude with changed objects, actual verification, runtime evidence, remaining risks and document location. Do not claim deployment, successful business behavior or transport release from source changes alone.
