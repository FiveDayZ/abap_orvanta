# Focused Review Checklist

Select checks relevant to the object and request. Do not report a checklist item as passed without reading the evidence.

| Area | Inspect |
| --- | --- |
| Inputs and DDIC | Required and conditional fields; valid domain values; conversion exits; dates; zero versus missing; duplicate rows; quantities/units and amounts/currencies |
| Authorization | Authenticated user and organization scope; immediate return-code handling; caller-controlled audit fields |
| State transitions | Allowed current states; duplicate actions; concurrent updates; expected-state predicates; stale reads |
| Transactions | Commit owner; hidden commits in called APIs; update tasks; partial writes; first error preservation; rollback behavior |
| Locks | Established business lock; acquisition before mutable reads; ownership and release on success/failure; reservations |
| Idempotency | External unique key; duplicate create/retry; lost-response behavior; full replacement versus partial patch |
| SQL | Empty `FOR ALL ENTRIES`; key uniqueness; deterministic selection; write counts; N+1 reads; unsafe dynamic SQL; bounded result size |
| Internal tables | Exact sort key before binary search; duplicate key handling; repeated lookup cost; mutation during iteration |
| RFC boundary | Remote-enabled interface; supported DDIC serialization; initialized outputs; session-persistent globals; messages/exceptions; no GUI dependencies |
| Shared behavior | Function-group includes; sibling callers; UI state assumptions; master-data derivation; compatibility with existing consumers |
| Source comments | Whether non-obvious business rules, routine contracts and side effects are explained near the code; whether existing explanations contradict actual conditions, ordering or commit behavior; do not equate comment volume with correctness |
| Recovery | Reversal completeness; persistent side effects; failed update tasks; truthful error/success response |
| Verification | Does the proposed test fail for the actual defect? Are runtime and persistence assertions available and authorized? |

## Severity Calibration

- Critical: evidence supports severe, broadly reachable compromise or irreversible business damage.
- High: reachable authorization bypass, significant data corruption, broken atomicity or major business-flow failure.
- Medium: a concrete incorrect result or failure under a narrower but meaningful condition.
- Low: limited-impact correctness issue.
- Suggestion: optional improvement without a demonstrated defect.

Calibrate severity to the proven impact and reachability, not the vocabulary of the checklist.

Missing or stale explanatory comments alone are `Suggestion`, not proof of a runtime defect. Cite the exact code and explain the maintenance ambiguity; report any independently confirmed behavioral defect separately. Comment review does not authorize source edits.

## Evidence Limits

Syntax success does not prove transaction correctness. Activation does not prove an RFC is callable. Unit mocks do not prove deployed integration. A transport assignment does not prove release or delivery. An empty dependency search does not prove an object is unused. Keep these distinctions in the final review.
