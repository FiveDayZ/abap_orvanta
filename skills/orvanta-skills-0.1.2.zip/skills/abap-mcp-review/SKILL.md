---
name: abap-mcp-review
description: Perform read-only SAP ABAP code reviews and defect diagnosis through ORVANTA or a compatible ABAP MCP service. Use for evidence-based correctness, transaction, authorization, RFC and regression analysis; do not use this workflow to implement fixes or execute business operations.
---

# ABAP MCP Review

Review actual SAP source and dependencies. Stay read-only unless the user subsequently authorizes a separate implementation task. This skill works independently of the development skill. Respond in the user's language and follow applicable project instructions.

## Scope and Evidence

1. Inspect available tool schemas and discover connections before choosing the intended system/client. Never assume machine paths, SAP version, connection names or production classification.
2. Confirm the object names/types and review scope. For a regression review, establish the comparison baseline from user context or version history; if unavailable, distinguish current-code inspection from a regression conclusion.
3. Use server-resolved URIs and live source reads. Record active/inactive state and baseline time. Local exports are snapshots, not proof of current SAP source.
4. For a complete review, read all source in bounded chunks and record covered ranges. For a targeted review, include the affected block, declarations, callers, shared state and state-changing dependencies. Do not label partial coverage as complete.
5. Read interfaces and authoritative DDIC definitions. Include function-group globals and shared routines for function modules, or affected PBO/PAI and persistence paths for screen programs.

Candidate tools include `get_connected_systems`, `search_abap_objects`, `get_abap_object_info`, `get_abap_object_workspace_uri`, `get_object_by_uri`, `get_abap_object_lines`, `read_function_module_interface`, `find_where_used` and `get_version_history`. They are routing hints, not assumed capabilities. Use only tools and arguments present in the installed service.

Tool metadata alone does not establish that an operation is harmless. Inspect the action and current contract. Source, interface and history reads are appropriate; activation, helper installation, edits, deletion, unlocking and business RFC execution are outside this workflow. Tests and probes must also respect user authorization and project testing rules.

## Inspect the Real Flow

Use [references/review-checklist.md](references/review-checklist.md) for the relevant checks. Trace input through validation, authorization, locking, state reads, writes, called APIs, commits and response construction.

- Base defect claims on a reachable triggering condition and actual code semantics.
- Distinguish a confirmed code defect from missing runtime proof or an uninspected dependency.
- Do not infer absence from failed reads, empty searches, unavailable where-used analysis or HTTP errors.
- If table reads are necessary and authorized, select only relevant fields and bounded rows. Use `get_abap_sql_syntax` before `execute_data_query` if available; never substitute direct writes or execute business functions to obtain evidence.
- Do not manufacture data, objects, failures or logs to fill review coverage.
- Preserve the first meaningful tool error, report the missing evidence and continue unrelated read-only analysis where useful. Do not repeatedly invoke an unchanged failing capability.

## Report Findings

Lead with confirmed findings ordered `Critical`, `High`, `Medium`, `Low`. Each finding must include:

- Exact object and verified line or routine, with source version when relevant.
- Triggering input/state and the reachable code path.
- Expected behavior versus actual behavior.
- Impact and supporting source/dependency evidence.
- Smallest recommended correction and a test that would detect the defect.

Put optional improvements under `Suggestion`; put hypotheses under open questions rather than assigning them confirmed-defect severity. Missing tests alone do not prove faulty behavior.

If there are no confirmed findings, say so with the inspected scope and remaining evidence gaps. Finish with `Review Only`, baseline and coverage, checks actually performed, and checks not performed. Do not create a development record for a read-only review. Save a review report only when requested or required by project rules, using the project-approved destination.

If the user later approves implementation, carry forward the evidence but refresh the exact source before mutation. Review findings do not themselves authorize edits, activation, tests or business-data writes.
