# ABAP Source Comments

Read before generating or changing ABAP source. The goal is maintainable business code, not maximum comment density. These rules do not authorize extra objects, behavioral changes or SAP writes.

## Language and Placement

- Follow the explicit project convention. Otherwise write comments in the user's language; use Chinese for a Chinese-language task without a contrary convention.
- Place a short explanation immediately before the non-obvious block. Use an end-of-line comment only for a short qualifier that remains readable.
- Use ordinary ABAP comments: `"` starts a comment to the end of the line; `*` is a full-line comment only in column one. Preserve the object's existing format. Do not introduce pragmas or pseudo-comments to suppress checks.
- Do not alter generated function-module interface headers. Put additional business explanations in editable source outside generated sections.
- Do not invent authors, dates, change-ticket numbers, test results or historical reasons. Keep secrets and real personal data out of examples and comments.

## What Needs an Explanation

Use the following only where the information is not already clear from names and nearby code. State verified facts, not an intended guarantee the implementation does not provide.

| Location | Explain when non-obvious |
| --- | --- |
| Program or include entry | Business responsibility or cross-include dependency that a maintainer cannot infer from the name; keep implementation explanations in the owning include |
| FM, method, FORM or screen module | Business purpose, unusual input/output meaning, required state, mutation of shared state, error handling or transaction ownership; describe only the relevant contract |
| Types, constants and shared data | Business meaning of ambiguous statuses, special initial values, units, lifetime or cross-call reset requirements; do not repeat the declaration |
| Validation and state branches | Business reason for the restriction, especially zero versus missing, duplicate actions and allowed transitions |
| SQL and internal-table operations | Intentional selection priority, tie-breaker, duplicate treatment, aggregation meaning or dependence on prior sorting/filtering |
| Locks, writes and commits | The invariant being protected, required operation order, who owns commit/rollback and which side effects or cleanup are actually covered |
| Exceptions and compatibility code | Why fallback or legacy syntax is necessary, what failure it handles and what limitation remains |

For a multi-stage business routine, comment the meaningful transitions rather than every statement. A simple wrapper or clearly named assignment does not need a header. Do not require every section of a generic template for every routine.

## Examples

The following fragments illustrate comment quality only. Variables, requirements and surrounding operations are illustrative, not verified SAP objects or executable integration examples. Do not copy the business assumptions into a real object without checking its actual contract.

### Explain a Business Rule

Assumption for this example: a zero quantity is accepted for a later allocation step; negative quantities are invalid.

```abap
" 零数量表示尚待分配，只拒绝负数，不能改为小于等于零。
IF iv_quantity < 0.
  ev_invalid = 'X'.
  RETURN.
ENDIF.
```

Avoid comments that merely translate the syntax:

```abap
" 判断数量是否小于零。
IF iv_quantity < 0.
  " 设置错误标识。
  ev_invalid = 'X'.
  RETURN.
ENDIF.
```

### Explain a Contract at Its Ownership Point

Only if live source confirms caller-owned transaction handling, an appropriate routine comment is:

```abap
" 本例程登记变更但不提交；调用方需在整笔业务成功后统一提交。
```

Place it at the routine boundary. Do not claim complete rollback unless all relevant called APIs and side effects support it. If an API commits internally, document the verified limitation rather than claiming atomicity.

### Explain Ordering or a Compatibility Constraint

Only where the verified flow requires it, use comments such as:

```abap
" 获取业务锁后重新读取状态，防止按加锁前的旧状态重复处理。
```

```abap
" 同一日期按单据号排序，使重复查询的分配顺序保持一致。
```

Put each comment beside the corresponding implemented operation, not above unrelated declarations. Do not add one as a substitute for the missing lock, re-read or deterministic sort.

## Existing Code and Readback

1. Identify non-obvious rules and side effects in the changed scope before editing. Add their explanations with the implementation, not as an optional documentation follow-up.
2. Preserve useful existing comments. Correct or remove a stale comment in the affected block when current evidence contradicts it; do not infer the original author's reasoning.
3. Keep legacy code outside the approved scope unchanged. A behavioral fix is not permission to annotate all includes or replace interface documentation.
4. During source readback, check:
   - Can a maintainer understand the business reason and non-obvious contract at the changed code?
   - Do comments agree with conditions, units, sort keys, state transitions and actual commit/error handling?
   - Are the comments concise, in the expected language and inside valid ABAP comment syntax?
   - Are any comments just narrating obvious statements, inventing guarantees or hiding missing implementation?
5. Do not declare annotation quality from a keyword or comment-count check. Inspect meaning against the source. Syntax checks establish comment syntax only; real generation behavior remains subject to the task's testing policy.
