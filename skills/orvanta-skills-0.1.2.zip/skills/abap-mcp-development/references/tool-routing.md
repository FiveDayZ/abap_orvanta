# Tool Routing

Read this when selecting tools. Names below were inspected in ORVANTA local source version 0.40.1 on 2026-09-14; this is not a tested installation compatibility range. Live tool discovery and schemas take precedence. Never invent parameters or call a missing tool.

| Intent | Candidate tools | Boundary |
| --- | --- | --- |
| Establish connection | `get_connected_systems` | Confirm the intended target; redact sensitive connection details |
| Investigate capabilities | `get_capability_report` | Read its schema and probe scope; registration is not backend readiness |
| Find an object | `search_abap_objects`, `get_abap_object_info` | Resolve exact name, type and ownership |
| Resolve and read source | `get_abap_object_workspace_uri`, `get_object_by_uri`, `get_abap_object_lines` | Keep active/inactive distinction; record incomplete coverage |
| Read function interface | `read_function_module_interface` | Read implementation and DDIC dependencies as well |
| Trace dependencies | `find_where_used`, source reads | Missing or unsupported results do not prove no callers |
| Inspect history | `get_version_history` | Historical source does not replace the current baseline |
| Replace source | `replace_string_in_abap_object` | Requires write authorization; inspect automatic activation behavior |
| Check syntax | `get_abap_diagnostics` | Current source contract checks active source without saving or activating |
| Separate activation | `abap_activate` | Mutation; not a read-only diagnostic |
| Quality and unit checks | `run_atc_analysis`, `run_unit_tests` | Respect testing authorization and actual backend support |
| Read table data | `read_abap_table` | Use explicit fields, filters and a bounded row count |
| Read SQL data | `get_abap_sql_syntax`, then `execute_data_query` | Read the syntax guide first; use bounded read-only SELECT only |
| Inspect transport | `manage_transport_requests` | Inspect the selected action; do not infer mutation/release capability |

## Source Replacement Contract

The inspected source contract uses `fileUri`, `oldString`, `newString`, optional `transportNumber` and optional `expectedSourceFingerprint`, plus shared write-operation inputs. Discover those shared fields from the installed service rather than guessing them.

In that source baseline the replacement operation saves, unlocks and activates; it rejects pre-existing inactive source and does not create or release transports. Therefore approval for a draft-only edit is insufficient for this operation. If the user forbids activation, stop and seek a supported draft-only workflow rather than invoking it.

For unavailable capabilities, report the exact unsupported result. Do not install an SAP helper, use an older helper namespace, switch connections, execute a function or change endpoint configuration as an automatic fallback.
